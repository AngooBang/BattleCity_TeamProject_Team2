#pragma once
#include "Config.h"
#include "Singleton.h"

class GameEntity;
class SceneManager : public Singleton<SceneManager>
{
private:
	map<string, GameEntity*> mapScenes;
	map<string, GameEntity*> mapLoadingScenes;

public:
	static GameEntity* currScene;			// ���� ��� ���� ��
	static GameEntity* readyScene;			// �غ� ���� ��
	static GameEntity* loadingScene;		// �ε� ��


	void Init();
	void Update();
	void Render(HDC hdc);
	void Release();

	void AddScene(string key, GameEntity* scene);
	void AddLoadingScene(string key, GameEntity* scene);

	HRESULT ChangeScene(string sceneName);
	//HRESULT ChangeScene(string sceneName, string loadingSceneName);
};

