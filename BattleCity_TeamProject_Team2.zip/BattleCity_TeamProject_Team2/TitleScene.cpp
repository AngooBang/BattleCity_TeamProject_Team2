#include "TitleScene.h"

HRESULT TitleScene::Init()
{
	return S_OK;
}

void TitleScene::Update()
{
}

void TitleScene::Render(HDC hdc)
{
}

void TitleScene::Release()
{
}
