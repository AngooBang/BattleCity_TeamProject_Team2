#include "ItemManager.h"

HRESULT ItemManager::Init()
{
    return S_OK;
}

void ItemManager::Update()
{
}

void ItemManager::Render(HDC hdc)
{
}

void ItemManager::Release()
{
}
