#include "GameEntity.h"
#include "Singleton.h"

HRESULT GameEntity::Init()
{
	return S_OK;
}

void GameEntity::Update()
{
}

void GameEntity::Render(HDC hdc)
{
}

void GameEntity::Release()
{
}
