#pragma once
#include "GameEntity.h"

class Item;
class ItemManager : public GameEntity
{
private:
	vector<Item*> m_vecItems;

public:
	HRESULT Init();
	void Update();
	void Render(HDC hdc);
	void Release();
};

